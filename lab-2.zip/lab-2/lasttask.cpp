#include <iostream>
using namespace std;

int calculateGCD(int a,int b,int c) {
    if (a%c== 0 && b % c == 0) {
        return c;
    }
    return calculateGCD(a,b,c - 1);
}

int calculateLCM(int a,int b) {
    return(a*b)/calculateGCD(a,b,max(a,b));
}

int main() {
    int num1, num2;
    cout << "Enter first number: ";
    cin >> num1;
    cout << "Enter second number: ";
    cin >> num2;

    int gcd = calculateGCD(num1, num2, max(num1, num2));
    int lcm = calculateLCM(num1, num2);

    cout<<"GCD of"<<num1<<"and"<<num2<<"is:"<< gcd << endl;
    if (num1!=0&&num2!= 0) {
        cout<<"LCM of "<<num1<<"and"<<num2<< " is:"<<lcm<<endl;
    } else {
        cout<<"LCM of"<<num1<<" and"<<num2<<"is undefined"<<endl;
    }
}
   

