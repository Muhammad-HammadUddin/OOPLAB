//Roll Number 23k-0863
#include<iostream>
using namespace std;
void grade(float marks){
	if (marks>=90.00){
		cout<<"A grade"; 
	}
	else if(marks>=80.00){
		cout<<"B grade"; 
	}
	else if(marks>=70.00){
		cout<<"C grade"; 
	}
	else if(marks>=60.00){
		cout<<"D grade"; 
	}
}
void subject(int i,int j){
	if(j==0){
			cout<<"enter marks for "<<i+1<<" student subject mathematics\n";
	}
	if(j==1){
		cout<<"enter marks for"<<i+1<<"student subject English\n";
	}
	if(j==2){
		cout<<"enter marks for"<<i+1<<"student subject Science\n";
	}
}
int main(){
	int a;
	cout<<"enter number of students";
	cin>>a;
	float arr[a][3];
	for(int i=0;i<a;i++){
		for(int j=0;j<3;j++){
			
		
		subject(i,j);
		cin>>arr[i][j];
	}}
	
	for(int i=0;i<a;i++){
		
		float averagemarks=0;
		float  marks=0;
		for(int j=0;j<3;j++){
			marks+=arr[i][j];
			
		}
		
		averagemarks=marks/3;
		cout<<"Total Obtained marks for "<<i+1<<"is "<< marks<<"\n";
		cout<<"Average marks for "<<i+1<<"is "<<averagemarks<<"\n";
		grade(marks/3);
	}
}
