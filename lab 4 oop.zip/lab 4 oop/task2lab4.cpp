//23K-0863





//For the above question, remove the parameterized constructor, and update the default constructor such that it sets
//the number of pages to 1000, and number of pages read to 0, through a member initialization list.
//Generate setters for the remaining three attributes, and update the values of the member variables using those setters
//in the main function.
//Also create a method called �showBookInfo� that displays all the information about the variables. Call this function
//in your main method as well.
#include<iostream>
using namespace std;
class book{
	string name;
	string author;
	int ISBN_NUMBER;
	int numberofpages;
	int pages_read;
	public:
		book(){
			numberofpages=1000;
			pages_read=0;
		}
		
	string getname(){
		return name;
	}
	string getauthor(){
		return author;
	}
	int getISBN_NUMBER(){
		return ISBN_NUMBER;
	}
	int getnumberofpages(){
		return numberofpages;
	}
	int getpages_read(){
		return pages_read;
	}
	void setname(string a){
		name=a;
	}
	void setauthor(string b){
		author=b;
	}
	void setISBN_NUMBER(int a){
		ISBN_NUMBER=a;
	}
	void setnumberofpages(int b){
		numberofpages=b;
	}
	void setpages_read(int c){
		pages_read=c;
	}
	void showinfo(){
		cout<<"Author of book :"<<author<<endl;
		cout<<"Name of book :"<<name<<endl;
		cout<<"Total Pages :"<<numberofpages<<endl;
		cout<<"Reamaining Pages :"<<pages_read<<endl;
	}
};
int main(){
	book s1;
	s1.setauthor("Liza");
	s1.setname("Harry Potter");
	s1.setnumberofpages(100);
	s1.setpages_read(50);
	s1.showinfo();
}
