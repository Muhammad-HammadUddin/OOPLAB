//ROLL NUMBER:23K-0863
//Create a class called water bottle.
//The water bottle has a company (made by), color and water capacity. The water capacity is stored in both
//liters(l) and milliliters(ml).
//Create variables and methods for your class. Methods should include getters and setters.
//Also create an additional method that updates the water capacity (both in l and ml) after asking user how
//much water a person has drank. Assume that the user always enters the amount in ml.
//Demonstrate the functionality of the water bottle in your main method.
#include<iostream>
using namespace std;
class waterbottle{
	string company;
	string color;
	int capacityml;
	int capacitylit;
	
	public:
		string getcompany(){
			return company;
		}
		void setcompany(string Company){
			company=Company;
		}
	    string getcolor(){
		return color;
	    }
	    void setcolor(string Color){
	    	color=Color;
		}
	    int capacity(){
	    	return capacityml;
		}
		void setcapacity(int Capacity){
			capacityml=Capacity;
			capacitylit=Capacity*1000;
		}
		void checkcapacity(int capml){
			int capl=capml*1000;
			capacityml-=capml;
			capacitylit-=capl;
		}
	    
	
};
int main(){
	waterbottle w1;
	w1.setcompany("XYZ");
	w1.setcolor("BLUE");
	w1.setcapacity(1000);
	int a,b=0;
	while(b!=-1){
		cout<<"Enter how many ml a person has drunk";
	cin>>a;
	
	w1.checkcapacity(a);
	
	cout<<"do you want to add more if no press -1 ?";
	cin>>b;
	}
	
	
}

