#include <iostream>
#include <string>
using namespace std;

class RetailItem {
private:
    string description;
    int unitsOnHand;
    double price;

public:
    
    RetailItem(string desc, int units, double cost) {
        description = desc;
        unitsOnHand = units;
        price = cost;
    }

    
    string getDescription() const {
        return description;
    }

    int getUnitsOnHand() const {
        return unitsOnHand;
    }

    double getPrice() const {
        return price;
    }

    
    void setDescription(string desc) {
        description = desc;
    }

    void setUnitsOnHand(int units) {
        unitsOnHand = units;
    }

    void setPrice(double cost) {
        price = cost;
    }
};

int main() {
    
    RetailItem item1("Jacket", 12, 5990.95);
    RetailItem item2("Designer Jeans", 40, 3432.95);
    RetailItem item3("Shirt", 20, 2494.95);

    
    cout<<"Item #1\nDescription: "<<item1.getDescription()<<"\nUnits on Hand: "<<item1.getUnitsOnHand()<<"\nPrice: "<<item1.getPrice()<<endl;
    cout<<"Item #2\nDescription: "<<item2.getDescription()<<"\nUnits on Hand: "<< item2.getUnitsOnHand()<<"\nPrice: "<<item2.getPrice()<<endl<<endl;
    cout<<"Item #3\nDescription: "<<item3.getDescription()<<"\nUnits on Hand: " << item3.getUnitsOnHand()<<"\nPrice: "<<item3.getPrice()<<endl;

    return 0;
}

