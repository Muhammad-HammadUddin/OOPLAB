//Create a class for a stationary shop.
//The stationary shop maintains a list for all the items that it sells (hint: array of strings), and another listwith the
//prices of the items (hint: array of prices).
//Create a menu-driven program to: the items and their prices.
//2. Fetch the list of
//1. Allow the shop owner to add items
//3. Edit the prices of the items
//4. View all the items and their prices
//Create a receipt that the shopkeeper can share with their customers. The receipt can only becreated after the
//shopkeeper inputs the items and their amounts bought by the customer.

#include<iostream>
using namespace std;
class shop{
	string items[100];
	int prices[100];
	int quantity[100];
	int count;
	public:
		shop(){
			count=0;
		}
		void add(){
			cout<<"Enter name of item";
			cin>>items[count];
			cout<<"enter price of"<<count<<" item";
			cin>>prices[count];
			cout<<"enter quantity of"<<count<<" item";
			cin>>quantity[count];
			count++;
		}
		void itemandprice(){
			
			for(int i=0;i<=count;i++){
				cout<<i<<"item name :"<<items[i]<<" price :"<<prices[i]<<endl;
		}
	}
		void edit(int a){
			
			cout<<"enter new price for "<<a<<"item"<<endl;
			cin>>prices[a];
		}
		void listofitems(){
				for(int i=0;i<count;i++){
				cout<<i<<"item name :"<<items[i]<<endl;
			}
			
		}
		void receipt(){
			int total=0;
			cout<<"receipt "<<endl;
			for(int i=0;i<count;i++){
				cout<<i <<" item name :"<<items[i]<<" price :"<<prices[i]<<endl;
				total+=prices[i]*quantity[i];
			}
			cout<<"Total bill is"<<total<<"\n";
		}
			
		
};
int main(){
	class shop s;
	int i=0;
	int a;
	while(i!=-1){
		cout<<"enter 1 to add item\n";
		cout<<"enter 2 to show items and prices\n";
		cout<<"enter 3 to edit price\n";
		cout<<"enter 4 to generate receipt\n";
		cout<<"enter -1 to exit\n";
		cin>>i;
		
		switch(i){
			case 1:
				s.add();
				break;
			case 2:
				s.itemandprice();
				break;
			case 3:
				cout<<"enter index to edit value";
				cin>>a;
				s.edit(a);
				break;
			case 4:
				s.receipt();
				break;
			default:
				cout<<"Invalid";
				
		}
	}
	
}
