
#include<iostream>
using namespace std;
class office {
	string location;
	int seating_capacity;
	string furniture[3];
	public:
		office():location(""),seating_capacity(0),furniture({"","",""}){
			
		}
		office(string l,int b):location(l),seating_capacity(b){
		}
		office(string s):location(s){
			
		}
		office(string l,int b,string f[3]):location(l),seating_capacity(b){
			for (int i = 0; i < 3; ++i) {
            furniture[i] = f[i];
			
		}
};
int main(){
     office o;
     office o1("hello");
     office o2("hello",10);
     string f[3] = {"hello", "hey", "bye"};
     office o3("hello",20,f);
}
