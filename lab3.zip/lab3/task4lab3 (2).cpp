//ROLL NUMBER:23k-0863
//Create a class called Smartphone with the following attributes:
//? Company
//? Model
//? Display Resolution
//? RAM
//? ROM
//? Storage
//Create getter and setter methods for your attributes. A smartphone has some specific actions that it can perform.
//For example:
//1. Make a phone call
//2. Send a message
//3. Connect to the wifi
//4. Browse the internet
//
//CL1004 - Object Oriented Programming Lab 2024
//Create different smartphone objects. Set their attributes using the setter functions, and display their attributes after
//using the getter functions to fetch the attributes.
#include<iostream>
using namespace std;
class smartphone{
    
	string company;
	string model;
	int resolution;
	int ram;
	int rom;
	int storage;
	public:
	string getcompany(){
		return company;
	}
	string getmodel(){
		return model;
	}
	int getresolution(){
		return resolution;
	}
	int getram(){
		return ram;
	}
	int getrom(){
		return rom;
	}
	int getstorage(){
		return storage;
	}
	void setcompany(string s){
		company=s;
	}
	void setmodel(string m){
		model=m;
	}
	void setresolution(int r){
		resolution=r;
	}
	void setram(int Ram){
		ram=Ram;
	}
	void setrom(int Rom){
		rom=Rom;
	}
	void setstorage(int Storage){
		storage=Storage;
	}
	void makePhoneCall(string number) {
        cout <<"Calling "<< number << " from " << company << " " << model << endl;
    }

    void sendMessage(string number, string message) {
        cout << "Sending message to " << number << " from " << company << " " << model << ": " << message << endl;
    }

    void connectToWifi(string wifiName) {
        cout << "Connecting to Wi-Fi network: " << wifiName << " using " << company << " " << model << endl;
    }

    void browseInternet() {
        cout << "Browsing the internet using " << company << " " << model << endl;
    }
	void print(){
		cout<<"Comapany name is:"<<company<<endl;
		cout<<"model name is:"<<model<<endl;
		cout<<"resolution os smartphone is :"<<resolution<<endl;
		cout<<"Ram of smartphone is:"<<ram<<endl;
		cout<<"Rom of smartphone is"<<rom<<endl;
		cout<<"Storage of smartphone is:"<<storage<<endl;
	}
};
int main(){
	smartphone s1;
	smartphone s2;
	s1.setcompany("Realme");
	s1.setmodel("Narzo 30");
	s1.setresolution(1360);
	s1.setram(6);
	s1.setrom(128);
	s1.setstorage(256);
	
	
	s2.setcompany("Infinix");
	s2.setmodel("Note 10");
	s2.setresolution(1000);
	s2.setram(12);
	s2.setrom(128);
	s2.setstorage(256);
     cout<<"Specifactions for smartphone s1 is" <<endl;
	s1.print();
	
	cout<<"Functions of s1 are:"<<endl;
	s1.makePhoneCall("03222978119");
    s1.sendMessage("03222978119", "Hello!");
    s1.connectToWifi("MyWiFi");
    s1.browseInternet();
	cout<<"Specifactions for smartphone s2 is" <<endl;
	s2.print();
	cout<<"Functions of s2 are:"<<endl;
	s2.makePhoneCall("03251783389");
    s2.sendMessage("03251783389", "Hello!");
    s2.connectToWifi("MyWiFi");
    s2.browseInternet();
}
