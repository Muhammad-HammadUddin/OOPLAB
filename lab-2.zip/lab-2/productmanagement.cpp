//Q5: You are tasked with building a simple product management system for an online store.
//1. Create a function that allows the addition of a new product to the system. The function
//should take parameters such as product name, price, quantity, and any other relevant
//details.
//2. Implement a function that takes a product ID as input and displays detailed information
//about the product, including its name, price, quantity in stock, and any other relevant
//details.
//3. Design a function that enables the update of product information. It should take a product
//ID as well as the new details (e.g., updated price, quantity, etc.) and modify the existing
//product&#39;s information accordingly.
//4. Create a function that removes a product from the system based on its product ID. Ensure
//
//that the inventory is updated after the removal.
#include<iostream>
using namespace std;
struct product{
	int id;
	string name;
	int price;
	int quantity;
};
void addproduct(product* newproduct,int count){
	product* ptr=new product[count];
	for(int i=0;i<count-1;i++){
		ptr[i]=newproduct[i];
	}
	cout<<"enter product id";
	cin>>ptr[count-1].id;
	cout<<"enter price";
    cin>>ptr[count-1].price;
    cout<<"enter quantity";
    cin>>ptr[count-1].quantity;
    cout<<"enter name of product";
    cin>>ptr[count-1].name;
}
void searchproduct(product* newproduct,int count){
	int check;
	cout<<"enter product id";
	cin>>check;
	for(int i=0;i<count;i++){
		if(newproduct[i].id==check){
			cout << "ID: " << newproduct[i].id << endl;
            cout <<"NAME: " << newproduct[i].name << endl;
            cout << "PRICE: " << newproduct[i].price << endl;
            cout << "QUANTITY: " << newproduct[i].quantity << endl;
            return;
        }
    }
    cout << "Product Not found" << endl;
		
	
}
void updateproduct(product* newproduct,int count){
	int b;
	cout<<"enter product id";
	cin>>b;
	for(int i=0;i<count;i++){
		if(newproduct[i].id==b){
			cout<<"enter product id";
	        cin>>newproduct[i].id;
	        cout<<"enter price";
            cin>>newproduct[i].price;
            cout<<"enter quantity";
            cin>>newproduct[i].quantity;
            cout<<"enter name of product";
            cin>>newproduct[i].name;
			
		}
		
	}
}
void deleteproduct(product*& products, int& count) {
    int idToDelete;
    cout << "Enter product ID to delete: ";
    cin >> idToDelete;
    int indexToDelete = -1;
    for (int i = 0; i < count; i++) {
        if (products[i].id == idToDelete) {
            indexToDelete = i;
            break;
        }
    }
    if (indexToDelete != -1) {
        
        for (int i = indexToDelete; i < count - 1; i++) {
            products[i] = products[i + 1];
        }
        count--; 
        product* newArr = new product[count];
        
        for (int i = 0; i < count; i++) {
            newArr[i] = products[i];
        }
        delete[] products; 
        products = newArr; 
        cout << "Product with ID " << idToDelete << " has been deleted." << endl;
    } else {
        cout << "Product with ID " << idToDelete << " not found." << endl;
    }
}
int main(){
	cout<<"Welcome to Product manangement system";
	int a=0;
	int count=0;
	product* products=0;
	
	while(a!=-1){
		cout << "Enter 1 for adding product\n";
        cout << "Enter 2 for searching product\n";
        cout << "Enter 3 to update product \n";
        cout << "Enter 4 to delete product\n";
        cout<<"Enter -1 to exit program\n";
        
        cin >> a;
        cin.ignore();
		switch(a){
		case 1:
			count++;
			products=new product[count];
			addproduct(products,count);
			break;
		case 2:
			searchproduct(products,count);
			break;
			
		case 3:
			updateproduct(products,count);
			break;
		case 4:
		     deleteproduct(products,count);
		     break;
		case -1:
			cout<<"Bye";
			break;
		default:
			cout<<"Invalid";
	}
		
	}
}
	

