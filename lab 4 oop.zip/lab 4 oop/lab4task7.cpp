//Task 2
//Design a class Cannonball to model a cannonball that is
//fired into the air. A ball has
//� An x- and a y-position.
//� An x-
//and a y-velocity.
//Supply the
//following
//methods:
//� A constructor with an x-position (the y-position is initially 0)
//� A method move(double sec) that moves the ball to the next position (First compute the
//distance traveled in sec seconds, using the current velocities, then update the x- and y-
//positions; then update the y-velocity by taking into account the gravitational acceleration of
//�9.81 m/s2; the x-velocity is unchanged.)
//� Methods getX and getY that get the current location of the cannonball
//� A method shoot whose arguments are the angle a and initial velocity v (Compute the x-
//velocity as v cos a and the y-velocity as v sin a; then keep calling move with a time interval of
//0.1 seconds until the y-position is 0; call getX and getY after every move and display the
//position.)
//Use this class in a program that prompts the user for the starting angle and the initial velocity. Then call
//shoot()
#include<iostream>
#include<cmath>
using namespace std;
class Cannonball{
	double x_pos;
	double y_pos;
	double x_velo;
	double y_velo;
	public:
		Cannonball(double x){
			x_pos=x;
			y_pos=0;
			x_velo=0;
			y_velo=0;
		}
	move(double sec){
		x_pos+=sec*x_velo;
		y_pos+=sec*y_velo;
		y_velo-=9.81*sec;
	}
	void info(double a,double v){
		
		
		x_velo=v *cos(a);
		y_velo=v *sin(a);
		while(y_pos>=0){
			move(0.1);
			cout<<"Current Position "<<getx_pos()<<","<<gety_pos()<<endl;
		}
	}
	double getx_pos(){
		return x_pos;
	}
	double gety_pos(){
		return y_pos;
	}
};
int main(){
	double angle, velocity;
    cout << "Enter the starting angle (in degrees): ";
    cin >> angle;
    cout << "Enter the initial velocity: ";
    cin >> velocity;
    double radians = angle * M_PI / 180.0;
    Cannonball ball(10);
    ball.shoot(radians, velocity);
    return 0;
}
	
}
