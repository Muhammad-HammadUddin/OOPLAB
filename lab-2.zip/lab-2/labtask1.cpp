#include<iostream>
using namespace std;
void reverse(int &a,int &b,int i=0){
	int temp;
	
	if(i==1){
		return;
	}
	
	temp=a;
	a=b;
	b=temp;
	reverse(a,b,i+1);
}
	

int main(){
	int a,b,i=0;
	cout<<"enter a";
	cin>>a;
	cout<<"enter b";
	cin>>b;
	reverse(a,b,0);
	   cout << "Swapped values: a = "<<a<< ", b = " << b << endl;
}
