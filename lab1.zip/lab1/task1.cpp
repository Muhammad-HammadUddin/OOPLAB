//Roll no 23k-0863
#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"enter number";
	cin>>a;
	int found=0;
	for(int i=2;i<=a/2;i++){
		if(a%i==0){
			cout<<"Number is not prime";
			found=1;
			break;
			
		}	
	}
	if(found==0 ){
			cout<<"  prime";
		}
	else if(a==1){
		cout <<"number is not prime"
	}
}

