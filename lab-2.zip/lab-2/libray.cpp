//Q2: Imagine you are tasked with creating a program to manage a library&#39;s book inventory. Each book
//has attributes such as title, author, publication year, and genre. Design a struct that effectively
//represents a book as a real-world entity. Then, write a simple program in a language of your choice
//that utilizes this struct to demonstrate the creation, modification, and display of book information.
//1. Extend the program to manage multiple books in an array.
//2. Implement a function to search for a book by title or author.
//3. Allow the user to input new books and update existing book information interactively.
#include <iostream>
using namespace std;

struct book {
    string title;
    string author;
    string Year;
    string genre;
};

void addbooks(book* newbooks, int count) {
    book* ptr = new book[count];
    for (int i = 0; i < count - 1; i++) {
        ptr[i] = newbooks[i];
    }
    cout << "Enter title of book: ";
    getline(cin, ptr[count - 1].title);
    cout << "Enter author of book: ";
    getline(cin, ptr[count - 1].author);
    cout << "Enter Year of book: ";
    getline(cin, ptr[count - 1].Year);
    cout << "Enter genre of book: ";
    getline(cin, ptr[count - 1].genre);
    count++;
}

void searchbook(book* newbooks, int count) {
    string check;
    cout << "Enter title of book: ";
    getline(cin, check);
    for (int i = 0; i < count; i++) {
        if (newbooks[i].title == check) {
            cout << "Title: " << newbooks[i].title << endl;
            cout << "Author: " << newbooks[i].author << endl;
            cout << "Year: " << newbooks[i].Year << endl;
            cout << "Genre: " << newbooks[i].genre << endl;
            return;
        }
    }
    cout << "Book Not found" << endl;
}


void updatebook(book* newbooks, int count) {
    int b;
    cout << "Enter book number to change: ";
    cin >> b;
    cin.ignore(); // Ignore the newline character
    cout << "Enter title of book: ";
    getline(cin, newbooks[b - 1].title);
    cout << "Enter author of book: ";
    getline(cin, newbooks[b - 1].author);
    cout << "Enter Year of book: ";
    getline(cin, newbooks[b - 1].Year);
    cout << "Enter genre of book: ";
    getline(cin, newbooks[b - 1].genre);
}

int main() {
    int count = 0;
    int a = 0;
    book* books = 0;

    cout << "Welcome to library management system\n";

    while (a != -1) {
        cout << "Enter 1 for adding books\n";
        cout << "Enter 2 for searching books by title\n";
        cout << "Enter 3 to update book information\n";
        cout << "Enter -1 to exit program\n";
        cin >> a;
        cin.ignore(); 
        switch (a) {
            case 1:
                count++;
                books = new book[count];
                addbooks(books, count);
                break;
            case 2:
                searchbook(books, count);
                break;
            case 3:
                updatebook(books, count);
                break;
            case -1:
                cout << "Exiting program" << endl;
                break;
            default:
                cout << "Invalid input. Please try again." << endl;
        }
    }

    delete[] books; // Free allocated memory before exiting
    return 0;
}

