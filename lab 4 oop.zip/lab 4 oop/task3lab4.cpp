//Create a class called WeekDays with the following private data members:
//� Days � String array of size 7
//� CurrentDay � integer variable
//Create the following constructors and member functions for the class:
//� Default Constructor � Initializes the Days array with values from Sunday to Saturday.
//� Parameterized Constructor � Accepts an integer value and assigns it to the CurrentDay variable. If the value
//is greater than 6, perform the mod operation on it and then use it. (For example: 8%7 = 1 ��� you�ll store
//1 in the CurrentDay variable). It also initializes the Days array with values from Sunday to Saturday.
//� getCurrentDay � Returns the value of the current day in string format. ( Days[CurrentDay] )
//� getNextDay � Returns the value of the next day in string format.
#include<iostream>
using namespace std;
class day{
		
	
	string days[7];
	int i;
	public:
		day(){
			days[0]="Sunday";
			days[1]="Monday";
			days[2]="Tuesday";
			days[3]="Wednesday";
			days[4]="Thursday";
			days[5]="Friday";
			days[6]="Saturday";
		}
		day(int n){
			days[0]="Sunday";
			days[1]="Monday";
			days[2]="Tuesday";
			days[3]="Wednesday";
			days[4]="Thursday";
			days[5]="Friday";
			days[6]="Saturday";
			i=n%7;
			
		}
		string getday(){
			return days[i];
		}
		string getnextday(){
			return days[i+1];
		}
		string getpreviousday(){
			if(i>0){
				return days[i-1];
			}
			else{
				return days[6];
			}
			
		}
		string getnthday(int n){
			return days[(i+n)%7];
		}
		
	};
int main(){
	day d(3);
	cout<<d.getday()<<"\n";
	cout<<d.getnextday()<<"\n";
	cout<<d.getpreviousday()<<"\n";
	cout<<d.getnthday(40)<<"\n";
}
