//ROLL NUMBER 23k-0863
#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"enter size of an array";
	cin>>a;
	int arr[a];
	for(int i=0;i<a;i++){
		cin>>arr[i];
	}
	int left=0;
	int right=a-1;
	int max=0;
	while(left<right){
		int area;
		if(arr[right]>arr[left]){
			area=(right-left)*(arr[left]);
			left++;
		}
		else{
			area=(right-left)*(arr[right]);
			right--;
		}
		if(max==0||area>max){
			max=area;
		
		}
		
		
	}
	cout << max;
}
