//ROLL NUMBER 23k-0863
#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"enter size of an array";
	cin>>a;
	int arr[a];
	for(int i=0;i<a;i++){
		cout<<"enter number for  "<< i<<"index";
		cin>>arr[i];
	}
	int targetsum;
	cout<<"enter target sum";
	cin>>targetsum;
	for(int i=0;i<a;i++){
		for(int j=i+1;j<a;j++){
			if (arr[i]+arr[j]==targetsum){
				cout << i<< j<<"\n";
			}
		}
	}
	
}
