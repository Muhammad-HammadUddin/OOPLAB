#include <iostream>
using namespace std;



bool subsetsum(int arr[],int size,int targetsum) {
    
    if (targetsum == 0) {
        return true;
    }

    
    if (size == 0||targetsum<0) {
        return false;
    }

    
   
    return subsetsum(arr, size - 1, targetsum - arr[size - 1]) || 
           subsetsum(arr, size - 1, targetsum);
}

int main() {
    int size;
    cout << "Enter the size of the array";
    cin >> size;

    if (size<=0) {
        cout<<"Invalid array size.\n";
        return 1;
    }

    int arr[size];
    cout<<"Enter "<<size<<"elements of the array:\n";
    for (int i=0;i<size;++i) {
        cout<<"Element "<<i+1<<":";
        cin>>arr[i];
    }

    int targetsum;
    cout<<"Enter the target sum:";
    cin>>targetsum;

    
    if (subsetsum(arr, size, targetsum)) {
        cout<<"There exists a subset with the given sum." << endl;
    } else {
        cout<<"No subset exists with the given sum." << endl;
    }

    return 0;
}

