//23K-0863






//Create a class for a Book. A book has a name, author, ISBN number, number of pages, etc. Create an additional
//variable that stores the number of pages read.
//For this task:
//� Create default and parameterized constructors for the Book class. Leave the default one empty, but
//parameterized one should initialize all the values. Values can be hardcoded from the main method.
//� Create a method that updates the number of pages read. If a person has read all the pages of the book, it
//should display �You have finished the book� instead. Call this method from your main to update the number
//of pages read.
#include<iostream>
using namespace std;
class book{
	string name;
	string author;
	int ISBN_NUMBER;
	int numberofpages;
	int pages_read;
	public:
		book(){
			
		}
		book(string nam,string auth,int a, int b,int c){
			name=nam;
			author=auth;
			ISBN_NUMBER=a;
			numberofpages=b;
			pages_read=c;
		}
	void updatepages(int number){
			
		if(number>  numberofpages -pages_read){
			cout<<"Invalid\n";
		}
		
		
			pages_read+=number;
			if(pages_read=numberofpages){
				cout<<"you have finished the book\n";
			}
			
		
		
		
		
		
	}
	
};
int main(){
	book s1("Harry Potter","Liza",56789,100,50);
	s1.updatepages(50);
}
