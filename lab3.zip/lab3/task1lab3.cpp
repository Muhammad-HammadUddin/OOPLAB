//Create a class called board marker with the following attributes:
//? Company (Dollar, etc) 
//? Color (black, red, etc)
//? Refillable (Boolean- either it�s refillable or not)
//? Ink status (Boolean- ink empty or not)
//Create appropriate getters and setters for the attributes of your class. Create the following additional methods:
//1. A method to write with the board marker. You have to write a check that first checks if the ink is empty. The
//method should display a message accordingly.
//2. A method to refill the board marker. The method should first check if the marker is refillable or not, then
//display an appropriate message.
//Demonstrate your class by creating an object, setting the values and then calling the functions.
#include<iostream>
using namespace std;
class boardmarker{
	string company;
	string color;
	bool refillablestatus;
	bool inkstatus;
	public:
	bool getrefillablestatus(){
		return refillablestatus;
	}
	void setrefillable(bool refillable){
		refillablestatus=refillable;
	}
	bool getinkstatus(){
		return inkstatus;
	}
	void setinkstatus(bool InkStatus){
		inkstatus=InkStatus;
	}
	string  getcompany(){
		return company;
	}
	string  getcolor(){
		return color;
	}
	
	void setcompany(string Company){
		company=Company;

	}
	void setcolor(string Color){
		color=Color;
	}
	void write(){
		if(inkstatus){
			cout<<"Open the cap and you can write with it";
			
		}
		else{
			cout<<"Ink is empty you cannot write";
		}
	}
	
	void refill(){
		if(refillablestatus){
			cout<<"Marker can be refilled";
		}
		else{
			cout<<"Marker is not refillable";
		}
	}
};
int main(){
	boardmarker b1;
	b1.setcolor("pink");
	b1.setcompany("Piano");
    b1.setrefillable(true);
    b1.setinkstatus(false);
    
    cout << "Company: " << b1.getcompany() << endl;
    cout << "Color: " << b1.getcolor() << endl;

    b1.write();
    b1.refill();
	
	
	
}
