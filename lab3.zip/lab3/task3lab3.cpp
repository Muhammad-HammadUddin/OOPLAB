//Create a class called calendar.
//The calendar should have 12 arrays for each month of the year, and a variable that stores information
//about the current year.
//The user is allowed to store their tasks to do against each day. Assume only one entry is needed per day.
//Create the following methods for your class:
//1. Add a task. This function accepts three parameters: task details, date and month. It should add
//a task on the day specified.
//2. Remove a task. Accepts the date and month as a parameter to remove the task from.
//3. Show tasks. This method should go through all of your months and print all the tasks allocated.
//Your task is to create one calendar object, then hardcode 5-6 tasks for your calendar. Then demonstrate
//how you�ll remove a task, and display the updated task list.
#include<iostream>
using namespace std;
class calender{
	string information;
	string arr[12][30];
	public:
	string getinformation(){
		return information;
	}
	void setinformation(string taskdetails){
		information=taskdetails;
	}
	void initialize(){
		for(int i=0;i<12;i++){
			for(int j=0;j<30;j++){
				arr[i][j]="0";
			}
		}
	}
	void addtask(int month, int day, string taskdetails){
		if (month<1||month>12||day<1||day>30) {
            cout<<"Invalid date!" << endl;
            return;
        } 
        else if (arr[month-1][day-1]!= "0") {
            cout<<"There's already a task scheduled for this day." << endl;
            return;
        } 
        else {
            arr[month-1][day-1]=taskdetails;
        }
	
	}
	void displayinformation(){
		for(int i=0;i<12;i++){
			for(int j=0;j<30;j++){
				
				if(arr[i][j]!="0"){
					cout<<"month :"<<i<<"date :"<<j<<"event:"<<arr[i][j]<<endl;
				}
			}
		}
	}
	void deletetask(int month,int day){
		arr[month-1][day-1]="0";
	}
	
	
};
int main(){
	calender c1;
    c1.initialize();
    
    c1.addtask(4,5,"hammadbirthday");
    c1.addtask(2,1,"Brother Marriage");
    c1.addtask(8,7,"Final Exams");
    c1.addtask(5,9,"Graduation");
    c1.displayinformation();
    cout<<endl;
	c1.deletetask(4,5);
	c1.deletetask(2,1);
	cout<<"Events after deleted are:\n";
	c1.displayinformation();
}
