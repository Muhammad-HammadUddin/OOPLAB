//You are tasked with implementing a simple Student Registration System in C++. Define two
//structures, Register and Student, where Register contains attributes courseId and courseName, and
//Student inherits from Register while having additional attributes such as studentId, firstName,
//lastName, cellNo, and email. Your goal is to create an array of Student structures to store
//information for five students.
//Write a C++ program that accomplishes the following tasks:
//1. Implement the Register and Student structures.
//2. Inherit the Register structure in the Student structure.
//3. Create an array of Student structures to store information for 5 students.
//4. Take input for each student, including their courseId, courseName, studentId, firstName,
//lastName, cellNo, and email.
//5. Display the information for all 5 students.
#include<iostream>
#include<string>
using namespace std;
struct Register{
	string courseid;
	string coursename;
	
};
struct student{
	string studentid,firstname,lastname,cellno,email;
	struct Register Myregister;
	
};
int main(){
	struct student mystudents[5];
	int i;
	for(i=0;i<5;i++){
		fflsuh(stdin);
		cout<<"enter student id \n"<i+1;
		getline(cin,mystudents[i].studentid);
		cout<<"enter first name  \n"<i+1;
		getline(cin,mystudents[i].firstname);
		cout<<"enter last name \n"<i+1;
		getline(cin,mystudents[i].lastname);
		cout<<"enter cell no  \n"<i+1;
		getline(cin,mystudents[i].cellno);
		cout<<"enter email \n"<i+1;
		getline(cin,mystudents[i].email);
		cout<<"enter course id \n"<i+1;
		getline(cin,mystudents[i].Myregister.courseid);
		cout<<"enter course id \n"<i+1;
		getline(cin,mystudents[i].Myregister.coursename);
	}
	cout<<"Printing the information";
	for(i=0;i<5;i++){
		fflsuh(stdin);
		cout<<" student id \n"<i+1;
		cout<<mystudents[i].studentid);
		cout<<" first name  \n"<i+1;
		cout<<mystudents[i].firstname);
		cout<<" last name \n"<i+1;
		cout<<mystudents[i].lastname);
		cout<<" cell no  \n"<i+1;
		cout<<mystudents[i].cellno);
		cout<<" email \n"<i+1;
		cout<<mystudents[i].email);
		cout<<" course id \n"<i+1;
		cout<<mystudents[i].Myregister.courseid);
		cout<<" course id \n"<i+1;
		cout<<mystudents[i].Myregister.coursename);
	}
	
}
