//23k-0863

//For the above question, remove the furniture array, and instead make it a pointer.
//Change the constructor such that it accepts a number instead of an array. This number should be the size of the
//array. Within your constructor ask dynamically allocate an array of the given size.
//Create a destructor for you class, which deallocates the memory allocated for your furniture pointer.
//In your main function, dynamically allocate an object of type Office by passing required values in the constructor
//arguments. Then delete the dynamically allocated object to verify if the destructor is being called properly.
#include<iostream>
using namespace std;
class office{
	string location;
	int capacity;
	string* furniture;
	public:
		office(int a){
			
			
			furniture=new string [a];
		}
		~office() { 
        delete[] furniture; 
    }
		
};

int main(){
	office* o1=new  office(5);
	delete o1;
}
