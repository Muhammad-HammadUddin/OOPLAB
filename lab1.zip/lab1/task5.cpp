//Roll number 23k-0863

#include <iostream>
#include <string>

using namespace std;

struct Event {
    string eventName;
    string eventDate;
    string eventVenue;
    string eventOrganizer;
};

void addEvent(Event*& eventsList, int& totalEvents) {
    Event* tempEventsList = new Event[totalEvents + 1];
    for (int i = 0; i < totalEvents; ++i) {
        tempEventsList[i] = eventsList[i];
    }
    delete[] eventsList;
    eventsList = tempEventsList;

    cout << "\nEnter details for the new event:\n";
    cout << "Event Name: ";
    cin.ignore();
    getline(cin, eventsList[totalEvents].eventName);
    cout << "Event Date: ";
    getline(cin, eventsList[totalEvents].eventDate);
    cout << "Event Venue: ";
    getline(cin, eventsList[totalEvents].eventVenue);
    cout << "Event Organizer: ";
    getline(cin, eventsList[totalEvents].eventOrganizer);

    totalEvents++;
}

void searchEventByDate(Event* eventsList, int totalEvents) {
    string searchDate;

    cout << "\nEnter date to search events: ";
    cin >> searchDate;

    cout << "\nEvents on " << searchDate << ":\n";
    bool found = false;
    for (int i = 0; i < totalEvents; ++i) {
        if (eventsList[i].eventDate == searchDate) {
            found = true;
            cout << "\nEvent Name: " << eventsList[i].eventName << endl;
            cout << "Event Date: " << eventsList[i].eventDate << endl;
            cout << "Event Venue: " << eventsList[i].eventVenue << endl;
            cout << "Event Organizer: " << eventsList[i].eventOrganizer << endl;
        }
    }
    if (!found) {
        cout << "No events found for the specified date.\n";
    }
}

int main() {
    int totalNumEvents = 0;
    Event* eventsList = 0;

    int userChoice = 0; 

    do {
        cout << "\nMenu:\n";
        cout << "1. Add Event\n";
        cout << "2. Search Events by Date\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> userChoice;

        switch(userChoice) {
            case 1:
                addEvent(eventsList, totalNumEvents);
                break;
            case 2:
                searchEventByDate(eventsList, totalNumEvents);
                break;
            case 3:
                delete[] eventsList;
                cout << "Exiting program.\n";
                return 0;
            default:
                cout<< "Invalid choice. Please enter a valid option.\n";
        }
    } while (true);

    return 0;
}

